﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Metalcoin.Core.Enums
{
    public enum TipoPerfil
    {
        Administrador = 1,
        Usuario = 2
    }
}
