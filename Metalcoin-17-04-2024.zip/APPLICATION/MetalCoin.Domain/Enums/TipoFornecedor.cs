﻿namespace MetalCoin.Domain.Enums
{
    public enum TipoFornecedor
    {
        PessoaFisica = 1,
        PessoaJuridica = 2
    }
}
