﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Metalcoin.Core.Enums
{
    public enum TipoFornecedor
    {
        PessoaFisica = 1,
        PessoaJuridica = 2
    }
}
