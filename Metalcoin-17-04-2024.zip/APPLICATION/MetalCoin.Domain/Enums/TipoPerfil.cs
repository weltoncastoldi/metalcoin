﻿namespace MetalCoin.Domain.Enums
{
    public enum TipoPerfil
    {
        Administrador = 1,
        Usuario = 2
    }
}
