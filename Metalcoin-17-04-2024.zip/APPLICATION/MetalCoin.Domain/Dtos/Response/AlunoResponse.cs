﻿namespace MetalCoin.Domain.Dtos.Response
{
    public class AlunoResponse
    {
        public string Cpf { get; set; }
        public string Nome { get; set; }
        public string Status { get; set; }
        public string Curso { get; set; }
        public string Turno { get; set; }
    }
}
